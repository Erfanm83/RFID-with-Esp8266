Version 8

first you should run the xampp apache and mysql
then run the server --> double click on the bat file in the server directory
go to this url in a browser --> localhost/university/server
after that connect/turnON the esp to pc
then detect a card 
and the status of the id will update to present in attendancereport database