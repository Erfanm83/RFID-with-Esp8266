<?php session_start();

include_once '../database.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the value from the user
    $aid = $_POST['aid'];

    $sql = "SELECT * FROM attendance WHERE aid = $aid";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        $_SESSION['aid'] = $aid;
    } else {
        echo "There is no class with this id !";
    }
}

?>

<!DOCTYPE html>
<html>


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Select Class Id</title>
    <link rel="icon" href="../../img/favicon2.png">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

    <link rel="stylesheet" href="../bower_components/bootstrap-daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="../plugins/timepicker/bootstrap-timepicker.min.css">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="../bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="../bower_components/select2/dist/css/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="../https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<body>
    <h4>Tag Id : <span id="tagId"> 0 </span></h4>
    <h4>Class Id : <span id="aid"><?php
                                    if (isset($_SESSION['aid'])) {
                                        echo $_SESSION['aid'];
                                    }
                                    ?></span>
    </h4>

    <script src="websocket.js"></script>

    <form method="POST" action="">
        <label for="aid">Enter Class Id:</label>
        <input type="text" name="aid" id="aid" required>
        <input type="submit" value="Submit">
    </form>

    <br>

    <form method="POST" action="">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Attendance ID</th>
                    <th>Subject</th>
                    <th>Classroom</th>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>

                <?php

                $sql = "SELECT attendance.aid, attendance.date, schedule.subject, schedule.class, schedule.stime FROM attendance, schedule where attendance.sid = schedule.id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td> " . $row["aid"] . " </td>
                                  <td> " . $row["subject"] . " </td>
                                  <td> " . $row["class"] . " </td>
                                  <td> " . $row["date"] . "</td>
                                  <td> " . $row["stime"] . "</td>
                                  <td><button  name='aid' id='aid' value=" . $row["aid"] . " onclick=buttonClicked(this.value)> Select </button></td>
                              </tr>";
                    }
                }

                ?>

            </tbody>
            <tfoot>
            </tfoot>
        </table>
    </form>

    <script>
        function buttonClicked(value) {
            document.getElementById("aid").innerHTML = value;
        }
    </script>
</body>

</html>