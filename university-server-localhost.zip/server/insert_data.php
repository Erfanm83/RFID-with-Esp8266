<?php session_start();

header('Content-Type: application/json');
include_once '../database.php'; 

$aid = 0;
$sid = 0;
$att = "Present";

if (isset($_SESSION['aid'])) {
    $aid = $_SESSION['aid'];
} 

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['tagId'])) {
    $sid = $data['tagId'];

    $sql = "SELECT * FROM attendancereport WHERE aid = $aid AND sid = '$sid'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0){
        $sql = "UPDATE attendancereport SET status = '$att' WHERE aid = $aid AND sid = '$sid'";
        mysqli_query($conn, $sql);
    }
}

$conn->close();

?>