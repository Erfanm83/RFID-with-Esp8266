//REPLACE WITH YOUR COMPUTER IP ADDRESS WHERE THE WEBSOCKET SERVER IS RUNNING
var socket = new WebSocket('ws://192.168.1.100:81');

socket.onmessage = function(event) {
  console.log(event.data);
  const data = event.data.split(":");

  const msg = data[0] || "";
  const sensor = data[1] || "";

  if (sensor == "nfc") {
    var tagId = msg;
    document.getElementById("tagId").innerHTML = tagId;

    // Send the tagId to the server
    if (tagId != "couldn't read id") {
      fetch('insert_data.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            tagId: tagId
          })
        })
        .then(response => response.json())
        .then(data => {
          console.log('Success:', data);
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    }
  }
};