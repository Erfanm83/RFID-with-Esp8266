/*************************************************************************************************
 *  Created By: Tauseef Ahmad
 *  Created On: 11 July, 2023
 *  
 *  YouTube Video: 
 *  My Channel: https://www.youtube.com/@AhmadLogs
 ***********************************************************************************************/

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include "HTTPSRedirect.h"
#include "Display.h"
#include <Wire.h>
#include <PN532_I2C.h>
#include <PN532.h>
#include <NfcAdapter.h>
#include <LiquidCrystal_I2C.h>
#include <ArduinoWebsockets.h> 
using namespace websockets;


const char* ssid     = "hossein"; 
const char* password = "hossein122133@!";

WebsocketsClient socket;
const char* websocketServer = "ws://192.168.1.100:81/";
boolean connected = false;

String prevTagId = "";
String tagId = "";

PN532_I2C pn532_i2c(Wire);
NfcAdapter nfc = NfcAdapter(pn532_i2c);


void setup() {
  Serial.begin(9600);
  Serial.println();

  nfc.begin();
  
  connectWiFi();
  connectToWebSocket();

  socket.onMessage(handleMessage);
  socket.onEvent(handleEvent);
}

void loop() {
  if(!connected) { 
    Serial.println("Connecting to WebSocket server");
    connectToWebSocket();
  }
  socket.poll();

  tagId = readNFC();

  if (tagId != prevTagId){
    socket.send(tagId + ":nfc:localhost:esp");
    Serial.println("tag's id sent to server");
    prevTagId = tagId;
    delay(1000);
  }
}

void handleMessage(WebsocketsMessage message) { 
  Serial.println(message.data());
  String data = message.data();

  String status = parseData(data, 1);
  String sensor = parseData(data, 2);
}

void handleEvent(WebsocketsEvent event, WSInterfaceString data) { 
  switch (event) {
    case WebsocketsEvent::ConnectionOpened:
      Serial.println("WebSocket connection established");
//      socket.send("Hello, server!");
      connected = true;
      break;
    case WebsocketsEvent::ConnectionClosed:
      Serial.println("WebSocket connection closed");
      connected = false;
      break;
    case WebsocketsEvent::GotPing:
      Serial.println("Received ping");
      break;
    case WebsocketsEvent::GotPong:
      Serial.println("Received pong");
      break;
    default:
      break;
  }
}

void connectToWebSocket() { 
  connected = socket.connect(websocketServer);
  if (connected) { 
    Serial.println("Connected");
  }
  else { 
    Serial.println("Connection failed.");
  }
}

void connectWiFi() {
  WiFi.begin(ssid, password);
  Serial.println("Connecting to WiFi");
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
    
  Serial.print("connected to : "); 
  Serial.println(ssid);
  Serial.print("IP address: "); 
  Serial.println(WiFi.localIP());
}

String parseData(String data, int index) {
  String result = "";
  int currentIndex = 1;
  int start = 0;
  int end = data.indexOf(":");

  while (end != -1 && currentIndex <= index) {
    if (currentIndex == index) {
      result = data.substring(start, end);
      break;
    }

    start = end + 1;
    end = data.indexOf(":", start);
    currentIndex++;
  }

  return result;
}


String readNFC() {
  if (nfc.tagPresent()) {
    NfcTag tag = nfc.read();
    tag.print();

    String id = tag.getUidString();
    Serial.print("Tag id : "); Serial.println(id);

    Serial.println("tag details :");
    String content = "";
    byte myByte[] = {0x00, 0xFF};
    tag.getUid(myByte, tag.getUidLength());
    for (int i = 0 ; i < tag.getUidLength(); i++){
      Serial.print(myByte[i] + " ");
    }
    content.toUpperCase();
    Serial.println("********************\n\n");
    
    delay(1000);
    return id;
  }
  return "couldn't read id";
}
